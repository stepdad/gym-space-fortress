void Gen_Explosion(int X_Pos,int Y_Pos,int Radius);

void Gen_Snap_Effect();
void Zero_Vulner_Sound();

void Jitter_Ship();
void Reset_All_Missiles();

void Test_Collisions();

void Accumulate_Data();
int Check_Collision(float First_X,float First_Y,float Second_X, float Second_Y, int Crash_Distance);