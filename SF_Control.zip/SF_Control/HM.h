/* ******************   Handle_Mine and all others elements   ***************** */



void Select_Mine_Menus();

void Update_Ship_Dynamics();

void Update_Ship_Display();
void Move_Ship();

void Fire_Shell();
void Handle_Fortress(); 

int randrange(int min, int max);

void Handle_Speed_Score();
void Clear_Mine_Type();

//void Show_Mine_Type(char *Minetype);
void Reset_Mine_Headings();

void Generate_Mine();
void Move_Mine();

void Handle_Square();


void Handle_Shell();
void Fire_Missile(int Index);
void Handle_Missile();
void Generate_Square();